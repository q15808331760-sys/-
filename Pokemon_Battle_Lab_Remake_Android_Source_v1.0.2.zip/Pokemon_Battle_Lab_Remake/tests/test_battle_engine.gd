extends SceneTree

const BattleEngine = preload("res://scripts/battle_engine.gd")

func _initialize() -> void:
	assert(BattleEngine.effectiveness("火", ["草"]) == 2.0, "Fire should be super effective against Grass")
	assert(BattleEngine.effectiveness("水", ["火"]) == 2.0, "Water should be super effective against Fire")
	assert(BattleEngine.effectiveness("电", ["地面"]) == 0.0, "Electric should not affect Ground")
	assert(BattleEngine.effectiveness("一般", ["岩石"]) == 0.5, "Normal should be resisted by Rock")
	assert(BattleEngine.effectiveness("冰", ["草", "地面"]) == 4.0, "Dual type multipliers should stack")
	assert(BattleEngine.move_info("喷射火焰").type == "火", "Move metadata should resolve")
	var attacker := {"type":"火", "atk":90, "spa":100}
	var defender := {"type":"草", "def":80, "spd":80, "hp":150}
	var result := BattleEngine.calculate_damage(attacker, defender, "喷射火焰")
	assert(not result.missed, "A 100% accuracy move should hit")
	assert(int(result.damage) > 0, "Super-effective move should deal damage")
	assert(float(result.effectiveness) == 2.0, "Damage result should expose effectiveness")
	assert(BattleEngine.weather_damage_multiplier("火", "大晴天") == 1.5, "Sun should boost Fire moves")
	assert(BattleEngine.weather_damage_multiplier("水", "下雨") == 1.5, "Rain should boost Water moves")
	assert(BattleEngine.weather_damage_multiplier("火", "下雨") == 0.5, "Rain should weaken Fire moves")
	assert(BattleEngine.terrain_move_multiplier("草", "青草场地") == 1.3, "Grassy terrain should boost Grass moves")
	var immune_mon := {"type":"火", "ability":"引火", "hp":100, "max_hp":100, "def":80, "spd":80}
	var blocked := BattleEngine.calculate_damage({"type":"火", "spa":100}, immune_mon, "喷射火焰")
	assert(int(blocked.damage) == 0 and blocked.has("ability_block"), "Flash Fire should block Fire moves")
	var status_target := {"type":"一般", "ability":"", "hp":100, "max_hp":100, "status":""}
	assert(BattleEngine.apply_status(status_target, "burn"), "A normal target should receive burn")
	assert(not BattleEngine.apply_status(status_target, "poison"), "A target should not receive a second major status")
	var poison_target := {"type":"钢", "ability":"", "hp":100, "max_hp":100, "status":""}
	assert(not BattleEngine.apply_status(poison_target, "poison"), "Steel types should be immune to poison")
	var damaged := BattleEngine.end_turn_effect(status_target)
	assert(int(damaged.damage) == 6, "Burn should deal one sixteenth max HP in this prototype")
	var leftovers := {"hp":50, "max_hp":100, "item":"吃剩的东西", "status":""}
	BattleEngine.end_turn_effect(leftovers)
	assert(int(leftovers.hp) == 56, "Leftovers should restore one sixteenth max HP")
	var fast_mon := {"spe":120, "status":""}
	var slow_mon := {"spe":70, "status":""}
	assert(BattleEngine.first_actor_speed(fast_mon, slow_mon) == "red", "Higher Speed should act first")
	var paralyzed_fast := {"spe":120, "status":"paralysis"}
	assert(BattleEngine.effective_speed(paralyzed_fast) == 60, "Paralysis should halve prototype Speed")
	var party := [
		{"hp":0},
		{"hp":30},
		{"hp":0}
	]
	assert(BattleEngine.next_healthy_member(party, 0) == 1, "Party rotation should select next healthy member")
	var prepared := BattleEngine.prepare_battle_member({"hp":45, "spe":90, "moves":[]})
	assert(prepared.max_hp == 45 and prepared.moves == ["撞击"], "Battle member should be normalized")
	print("PBL battle engine tests passed")
	quit(0)
