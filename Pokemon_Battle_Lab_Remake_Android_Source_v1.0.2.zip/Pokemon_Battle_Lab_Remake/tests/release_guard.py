#!/usr/bin/env python3
"""Fast, dependency-free consistency checks before Godot import/export."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

def require(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)

version = (ROOT / "VERSION.txt").read_text(encoding="utf-8").strip()
preset = (ROOT / "export_presets.cfg").read_text(encoding="utf-8")
lan = (ROOT / "scripts/lan_network.gd").read_text(encoding="utf-8")
lan_test = (ROOT / "tests/test_lan_network.gd").read_text(encoding="utf-8")
project = (ROOT / "project.godot").read_text(encoding="utf-8")
workflow = (ROOT.parent / ".github/workflows/android-apk.yml").read_text(encoding="utf-8")

require(version == "1.0.2", f"VERSION.txt must be 1.0.2, got {version!r}")
require('version/name="1.0.2"' in preset, "Android export preset version/name is not 1.0.2")
require("version/code=12" in preset, "Android export preset version/code must be 12")
require('gradle_build/min_sdk="23"' in preset, "Android minimum SDK must remain explicitly pinned to 23")
require('gradle_build/target_sdk="34"' in preset, "Android target SDK must be explicitly pinned to 34")
require("architectures/arm64-v8a=true" in preset, "ARM64 Android ABI must be enabled")
require("architectures/x86_64=true" in preset, "x86_64 Android ABI must be enabled for emulator/Intel devices")
require("permissions/internet=true" in preset, "Internet permission is required by LAN networking")
require("permissions/access_network_state=true" in preset, "Network state permission is required by LAN networking")
require("const PROTOCOL_VERSION := 3" in lan, "LAN protocol implementation must be v3")
require("PROTOCOL_VERSION == 3" in lan_test, "LAN tests must assert protocol v3")
require('run/main_scene="res://scenes/main.tscn"' in project, "Main scene setting is missing")
require((ROOT / "scenes/main.tscn").is_file(), "Configured main scene file is missing")
require("tests/test_battle_engine.gd" in workflow, "Battle engine tests are missing from CI")
require("tests/test_lan_network.gd" in workflow, "LAN tests are missing from CI")
require("tests/test_net_battle_session.gd" in workflow, "Network battle tests are missing from CI")
main_script = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
require('if net_battle.state.is_empty():\n\t\t\tnet_battle.start_replica()' in main_script, "Client must initialize replica role before applying its first battle snapshot")
require("apksigner" in workflow and "dump badging" in workflow, "APK package/signature checks are missing from CI")
require("android-emulator-runner" in workflow and "adb install -r" in workflow, "Android emulator install smoke test is missing from CI")
require("targetSdkVersion" in workflow and "native-code:" in workflow, "APK SDK/ABI verification is missing from CI")
require("Pokemon_Battle_Lab_Remake-debug.apk" in workflow, "APK artifact path is missing from CI")

# Every local res:// preload must point at a file included in this project.
for script in (ROOT / "scripts").glob("*.gd"):
    source = script.read_text(encoding="utf-8")
    for resource in re.findall(r'preload\("res://([^"]+)"\)', source):
        require((ROOT / resource).is_file(), f"{script.name} preloads missing resource: {resource}")

if errors:
    print("Release guard FAILED:")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)
print("Release guard passed: version, protocol, project paths, CI tests and APK checks are consistent.")
