extends SceneTree

const LanNetwork = preload("res://scripts/lan_network.gd")

func _initialize() -> void:
	var manager = LanNetwork.new()
	var incoming := [
		{"name":"测试训练家", "type":"火", "hp":99999, "atk":5000, "moves":["喷射火焰", "龙爪", "空气斩", "守住", "额外技能"], "unexpected":"must not pass"},
		{"name":"第二只", "hp":120}
	]
	assert(manager.PROTOCOL_VERSION == 3, "LAN protocol v3 is required for v0.9+ reconnect and action sequencing")
	var safe_team: Array = manager._sanitize_team(incoming)
	assert(safe_team.size() == 2, "LAN team exchange should retain valid party members")
	assert(int(safe_team[0].hp) == 9999, "Remote HP should be clamped")
	assert(int(safe_team[0].atk) == 999, "Remote stats should be clamped")
	assert(safe_team[0].moves.size() == 4, "Remote move list should be limited to four")
	assert(not safe_team[0].has("unexpected"), "Unknown remote fields should be discarded")
	assert(safe_team[1].name == "第二只", "Valid remote member data should be preserved")
	assert(manager.MAX_PACKET_BYTES > 0 and manager.MAX_RX_BUFFER_BYTES >= manager.MAX_PACKET_BYTES, "Network receive limits must be configured")
	assert(manager.MAX_RECONNECT_ATTEMPTS == 12, "Reconnect attempts must remain bounded")
	assert(manager.RECONNECT_INTERVAL == 2.0, "Reconnect interval must remain predictable")
	manager.free()
	print("PBL LAN network tests passed")
	quit(0)
