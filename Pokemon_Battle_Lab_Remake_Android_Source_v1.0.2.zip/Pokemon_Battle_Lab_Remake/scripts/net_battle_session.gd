class_name PBLNetBattleSession
extends RefCounted

const BattleEngine = preload("res://scripts/battle_engine.gd")

signal state_changed(snapshot: Dictionary)
signal log_added(message: String)
signal action_rejected(reason: String)

var is_authority := false
var state: Dictionary = {}
var pending_actions: Dictionary = {}
var local_action_pending := false
var local_side := "red"
var session_id := ""
var revision := 0
var action_counter := 0
var seen_action_ids: Dictionary = {}
var last_snapshot_revision := -1
var action_timeout_seconds := 45.0
var turn_elapsed_seconds := 0.0

func start_authority(host_team: Array, guest_team: Array) -> Dictionary:
	if host_team.is_empty() or guest_team.is_empty():
		return {"ok":false, "error":"双方都必须至少配置一只宝可梦。"}
	is_authority = true
	local_side = "red"
	session_id = "%d-%d" % [Time.get_ticks_msec(), randi()]
	revision = 1
	seen_action_ids.clear()
	last_snapshot_revision = revision
	state = _make_initial_state(host_team, guest_team)
	state["session_id"] = session_id
	state["revision"] = revision
	state["action_timeout_seconds"] = action_timeout_seconds
	state["remaining_seconds"] = action_timeout_seconds
	turn_elapsed_seconds = 0.0
	pending_actions.clear()
	local_action_pending = false
	return {"ok":true, "snapshot":make_snapshot()}

func start_replica() -> void:
	is_authority = false
	local_side = "blue"
	session_id = ""
	revision = 0
	last_snapshot_revision = -1
	turn_elapsed_seconds = 0.0
	seen_action_ids.clear()
	pending_actions.clear()
	local_action_pending = false

func _make_initial_state(red_team: Array, blue_team: Array) -> Dictionary:
	var red_party: Array = []
	var blue_party: Array = []
	for member in red_team.slice(0, 6):
		if member is Dictionary:
			red_party.append(BattleEngine.prepare_battle_member(member))
	for member in blue_team.slice(0, 6):
		if member is Dictionary:
			blue_party.append(BattleEngine.prepare_battle_member(member))
	return {
		"turn":1, "party_red":red_party, "party_blue":blue_party,
		"active_red":0, "active_blue":0, "weather":"无天气", "terrain":"无场地",
		"winner":"", "logs":["联机对战开始。房主负责权威计算。"]
	}

func submit_local_action(action: Dictionary) -> bool:
	if state.is_empty() or not str(state.get("winner", "")).is_empty():
		action_rejected.emit("当前没有进行中的联机战斗。")
		return false
	if local_action_pending:
		action_rejected.emit("本回合行动已提交，请等待对手。")
		return false
	if not _validate_action(local_side, action):
		action_rejected.emit("行动无效：请重新选择技能或可用替补。")
		return false
	if is_authority:
		pending_actions["red"] = action.duplicate(true)
		local_action_pending = true
		_try_resolve_turn()
	else:
		action_counter += 1
		var action_id := "%s-blue-%d" % [session_id, action_counter]
		pending_actions["blue"] = action.duplicate(true)
		pending_actions["blue"]["_action_id"] = action_id
		local_action_pending = true
		return true
	return true

func make_client_action_packet() -> Dictionary:
	var action: Dictionary = pending_actions.get("blue", {}).duplicate(true)
	var action_id := str(action.get("_action_id", ""))
	action.erase("_action_id")
	return {"protocol":3, "session_id":session_id, "turn":int(state.get("turn", 0)), "revision":revision, "action_id":action_id, "action":action}

func receive_remote_action(packet: Dictionary) -> bool:
	if not is_authority or state.is_empty():
		return false
	if int(packet.get("protocol", -1)) != 3 or str(packet.get("session_id", "")) != session_id:
		action_rejected.emit("行动包协议或对战会话不匹配。")
		return false
	if int(packet.get("turn", -1)) != int(state.get("turn", 0)) or int(packet.get("revision", -1)) != revision:
		action_rejected.emit("对手提交了过期或未来回合的行动。")
		return false
	var action_id := str(packet.get("action_id", ""))
	if action_id.is_empty() or action_id.length() > 128 or seen_action_ids.has(action_id):
		action_rejected.emit("重复或缺少行动编号，已拒绝该行动。")
		return false
	var action = packet.get("action", {})
	if not (action is Dictionary) or not _validate_action("blue", action):
		action_rejected.emit("对手提交的行动无效。")
		return false
	if pending_actions.has("blue"):
		action_rejected.emit("对手本回合已经提交行动。")
		return false
	seen_action_ids[action_id] = true
	if seen_action_ids.size() > 512:
		seen_action_ids.erase(seen_action_ids.keys()[0])
	pending_actions["blue"] = action.duplicate(true)
	_try_resolve_turn()
	return true

func _validate_action(side: String, action: Dictionary) -> bool:
	if state.is_empty() or not str(state.get("winner", "")).is_empty():
		return false
	var action_type := str(action.get("type", ""))
	var party: Array = state.get("party_red", []) if side == "red" else state.get("party_blue", [])
	var active_index := int(state.get("active_red", 0)) if side == "red" else int(state.get("active_blue", 0))
	if active_index < 0 or active_index >= party.size() or int(party[active_index].get("hp", 0)) <= 0:
		return false
	if action_type == "move":
		var moves: Array = party[active_index].get("moves", ["撞击"])
		var index := int(action.get("index", -1))
		return index >= 0 and index < moves.size()
	if action_type == "switch":
		var switch_index := int(action.get("index", -1))
		return switch_index >= 0 and switch_index < party.size() and switch_index != active_index and int(party[switch_index].get("hp", 0)) > 0
	return false

func _try_resolve_turn() -> void:
	if not is_authority or not pending_actions.has("red") or not pending_actions.has("blue"):
		return
	_resolve_turn()
	pending_actions.clear()
	local_action_pending = false
	turn_elapsed_seconds = 0.0
	state["remaining_seconds"] = action_timeout_seconds
	revision += 1
	state["revision"] = revision
	state_changed.emit(make_snapshot())

func _resolve_turn() -> void:
	# Switching occurs before attacks, so a move targets the newly active member.
	for side in ["red", "blue"]:
		var action: Dictionary = pending_actions[side]
		if str(action.get("type", "")) == "switch":
			var old_mon: Dictionary = _active_mon(side)
			var new_index := int(action.index)
			_set_active_index(side, new_index)
			_add_log("%s方收回 %s，派出 %s。" % [_side_name(side), old_mon.get("name", "宝可梦"), _active_mon(side).get("name", "宝可梦")])
	var actors := ["red", "blue"]
	var red_mon: Dictionary = _active_mon("red")
	var blue_mon: Dictionary = _active_mon("blue")
	if BattleEngine.first_actor_speed(red_mon, blue_mon) == "blue":
		actors.reverse()
	for side in actors:
		var action: Dictionary = pending_actions[side]
		if str(action.get("type", "")) != "move":
			continue
		var attacker: Dictionary = _active_mon(side)
		var defender_side := "blue" if side == "red" else "red"
		var defender: Dictionary = _active_mon(defender_side)
		if int(attacker.get("hp", 0)) <= 0 or int(defender.get("hp", 0)) <= 0:
			continue
		if str(attacker.get("status", "")) == "sleep" or BattleEngine.paralysis_prevents_action(attacker):
			_add_log("%s方的 %s 无法行动。" % [_side_name(side), attacker.get("name", "宝可梦")])
			continue
		var moves: Array = attacker.get("moves", ["撞击"])
		var move_name := str(moves[int(action.index)])
		if move_name == "守住":
			_add_log("%s方的 %s 使用守住。当前原型记录守住意图，但暂不实现完整保护判定。" % [_side_name(side), attacker.get("name", "宝可梦")])
			continue
		var result := BattleEngine.calculate_damage(attacker, defender, move_name, str(state.get("weather", "无天气")), str(state.get("terrain", "无场地")))
		if bool(result.get("missed", false)):
			_add_log("%s方的 %s 使用 %s，但没有命中。" % [_side_name(side), attacker.get("name", "宝可梦"), move_name])
		elif int(result.get("damage", 0)) > 0:
			defender["hp"] = maxi(0, int(defender.get("hp", 0)) - int(result.damage))
			_add_log("%s方的 %s 使用 %s，造成 %d 点伤害。" % [_side_name(side), attacker.get("name", "宝可梦"), move_name, int(result.damage)])
		else:
			_add_log("%s方的 %s 使用 %s，没有造成伤害。" % [_side_name(side), attacker.get("name", "宝可梦"), move_name])
		if int(defender.get("hp", 0)) <= 0:
			_add_log("%s方的 %s 倒下了。" % [_side_name(defender_side), defender.get("name", "宝可梦")])
	for side in ["red", "blue"]:
		var mon: Dictionary = _active_mon(side)
		if int(mon.get("hp", 0)) > 0:
			var effect := BattleEngine.end_turn_effect(mon)
			if not str(effect.get("message", "")).is_empty():
				_add_log("%s方的 %s：%s。" % [_side_name(side), mon.get("name", "宝可梦"), effect.message])
	_replace_fainted("red")
	_replace_fainted("blue")
	var red_alive := _party_alive("red")
	var blue_alive := _party_alive("blue")
	if not red_alive or not blue_alive:
		state["winner"] = "red" if red_alive else "blue" if blue_alive else "draw"
		_add_log("联机对战结束：%s。" % ("红方获胜" if state.winner == "red" else "蓝方获胜" if state.winner == "blue" else "平局"))
	else:
		state["turn"] = int(state.get("turn", 1)) + 1

func _replace_fainted(side: String) -> void:
	var mon := _active_mon(side)
	if int(mon.get("hp", 0)) > 0:
		return
	var party: Array = state["party_red"] if side == "red" else state["party_blue"]
	var current := int(state["active_red"] if side == "red" else state["active_blue"])
	var next_index := BattleEngine.next_healthy_member(party, current)
	if next_index >= 0:
		_set_active_index(side, next_index)
		_add_log("%s方自动派出 %s。" % [_side_name(side), _active_mon(side).get("name", "宝可梦")])

func _party_alive(side: String) -> bool:
	var party: Array = state["party_red"] if side == "red" else state["party_blue"]
	for member in party:
		if int(member.get("hp", 0)) > 0:
			return true
	return false

func _active_mon(side: String) -> Dictionary:
	var party: Array = state["party_red"] if side == "red" else state["party_blue"]
	var index := int(state["active_red"] if side == "red" else state["active_blue"])
	return party[index]

func _set_active_index(side: String, index: int) -> void:
	state["active_red" if side == "red" else "active_blue"] = index

func _side_name(side: String) -> String:
	return "红" if side == "red" else "蓝"

func _add_log(message: String) -> void:
	var logs: Array = state.get("logs", [])
	logs.append(message)
	while logs.size() > 80:
		logs.pop_front()
	state["logs"] = logs
	log_added.emit(message)

func make_snapshot() -> Dictionary:
	var snapshot := state.duplicate(true)
	snapshot["session_id"] = session_id
	snapshot["revision"] = revision
	snapshot["pending_red"] = pending_actions.has("red")
	snapshot["pending_blue"] = pending_actions.has("blue")
	return snapshot

func apply_authoritative_snapshot(snapshot: Dictionary, allow_same_revision: bool = false) -> bool:
	if is_authority or not _valid_snapshot(snapshot):
		return false
	var incoming_session := str(snapshot.get("session_id", ""))
	var incoming_revision := int(snapshot.get("revision", -1))
	if incoming_session.is_empty():
		return false
	if not session_id.is_empty() and incoming_session != session_id:
		return false
	if incoming_revision < last_snapshot_revision or (incoming_revision == last_snapshot_revision and not allow_same_revision):
		return false
	session_id = incoming_session
	revision = incoming_revision
	last_snapshot_revision = incoming_revision
	state = snapshot.duplicate(true)
	action_timeout_seconds = clampf(float(state.get("action_timeout_seconds", 45.0)), 10.0, 180.0)
	turn_elapsed_seconds = action_timeout_seconds - clampf(float(state.get("remaining_seconds", action_timeout_seconds)), 0.0, action_timeout_seconds)
	local_action_pending = bool(snapshot.get("pending_blue", false)) if local_side == "blue" else bool(snapshot.get("pending_red", false))
	pending_actions.clear()
	state_changed.emit(make_snapshot())
	return true

func tick_action_timer(delta: float) -> void:
	if state.is_empty() or not str(state.get("winner", "")).is_empty():
		return
	if is_authority:
		turn_elapsed_seconds = minf(action_timeout_seconds, turn_elapsed_seconds + maxf(0.0, delta))
		var remaining := maxf(0.0, action_timeout_seconds - turn_elapsed_seconds)
		state["remaining_seconds"] = remaining
		if remaining > 0.0:
			return
		var missing: Array[String] = []
		for side in ["red", "blue"]:
			if not pending_actions.has(side):
				missing.append(side)
		if missing.size() == 2:
			state["winner"] = "draw"
			_add_log("双方均未在时限内提交行动，本局判定平局。")
		elif missing.size() == 1:
			var loser := missing[0]
			state["winner"] = "blue" if loser == "red" else "red"
			_add_log("%s方行动超时，%s方获胜。" % [_side_name(loser), _side_name(str(state.winner))])
		pending_actions.clear()
		local_action_pending = false
		revision += 1
		state["revision"] = revision
		state_changed.emit(make_snapshot())
	else:
		# Replica countdown is display-only; only the host can decide a timeout.
		turn_elapsed_seconds = minf(action_timeout_seconds, turn_elapsed_seconds + maxf(0.0, delta))
		state["remaining_seconds"] = maxf(0.0, action_timeout_seconds - turn_elapsed_seconds)

func get_remaining_seconds() -> int:
	if state.is_empty():
		return int(action_timeout_seconds)
	return ceili(maxf(0.0, float(state.get("remaining_seconds", action_timeout_seconds))))

func forfeit_on_timeout(side: String, expected_turn: int) -> bool:
	if not is_authority or side not in ["red", "blue"] or state.is_empty():
		return false
	if expected_turn != int(state.get("turn", -1)) or not str(state.get("winner", "")).is_empty():
		return false
	if pending_actions.has(side):
		return false
	state["winner"] = "blue" if side == "red" else "red"
	_add_log("%s方行动超时，%s方获胜。" % [_side_name(side), _side_name(str(state.winner))])
	revision += 1
	state["revision"] = revision
	pending_actions.clear()
	local_action_pending = false
	state_changed.emit(make_snapshot())
	return true

func _valid_snapshot(snapshot: Dictionary) -> bool:
	var incoming_session := str(snapshot.get("session_id", ""))
	if not snapshot.has("turn") or int(snapshot.get("turn", 0)) < 1 or int(snapshot.get("revision", -1)) < 1 or incoming_session.is_empty() or incoming_session.length() > 128:
		return false
	if str(snapshot.get("winner", "")) not in ["", "red", "blue", "draw"]:
		return false
	if not (snapshot.get("logs", []) is Array) or snapshot.get("logs", []).size() > 80:
		return false
	var timeout_value := float(snapshot.get("action_timeout_seconds", 45.0))
	var remaining_value := float(snapshot.get("remaining_seconds", timeout_value))
	if timeout_value < 10.0 or timeout_value > 180.0 or remaining_value < 0.0 or remaining_value > timeout_value:
		return false
	if snapshot.has("pending_red") and not (snapshot.get("pending_red") is bool):
		return false
	if snapshot.has("pending_blue") and not (snapshot.get("pending_blue") is bool):
		return false
	if not (snapshot.get("party_red", []) is Array) or not (snapshot.get("party_blue", []) is Array):
		return false
	if snapshot.party_red.is_empty() or snapshot.party_blue.is_empty() or snapshot.party_red.size() > 6 or snapshot.party_blue.size() > 6:
		return false
	for side in ["red", "blue"]:
		var party: Array = snapshot["party_red"] if side == "red" else snapshot["party_blue"]
		var index := int(snapshot.get("active_red", 0) if side == "red" else snapshot.get("active_blue", 0))
		if index < 0 or index >= party.size() or not (party[index] is Dictionary):
			return false
		for member in party:
			if not (member is Dictionary):
				return false
			var max_hp := int(member.get("max_hp", 0))
			var hp := int(member.get("hp", -1))
			if max_hp < 1 or max_hp > 9999 or hp < 0 or hp > max_hp:
				return false
			if not (member.get("moves", []) is Array) or member.get("moves", []).size() > 4:
				return false
			if str(member.get("status", "")).length() > 24:
				return false
	return true
