extends Control

const SAVE_PATH := "user://pbl_remake_save.json"
const TYPES := ["一般", "火", "水", "电", "草", "冰", "格斗", "毒", "地面", "飞行", "超能力", "虫", "岩石", "幽灵", "龙", "恶", "钢", "妖精"]
const TYPE_COLORS := {"一般": Color("#929aa3"), "火": Color("#ef7045"), "水": Color("#4b91df"), "电": Color("#e9bd35"), "草": Color("#58a86a"), "冰": Color("#68c7d2"), "格斗": Color("#bd574d"), "毒": Color("#9a65ad"), "地面": Color("#b58a4e"), "飞行": Color("#8d9ed5"), "超能力": Color("#df6c9a"), "虫": Color("#91a83c"), "岩石": Color("#a58c59"), "幽灵": Color("#71649c"), "龙": Color("#6c65d9"), "恶": Color("#65565b"), "钢": Color("#8795a7"), "妖精": Color("#d78eb3")}

var teams := {"red": [], "blue": []}
var current_page := "home"
var editing_side := "red"
var editing_index := -1
var battle := {}
var log_lines: Array[String] = []
var selected_move := 0
var weather_select: OptionButton
var terrain_select: OptionButton
var ui_root: VBoxContainer
var content: Control
var page_title: Label
var status_label: Label
var lan_network: PBLLanNetwork
var lan_status_label: Label
var lan_peers_box: VBoxContainer
var lan_ip_edit: LineEdit
var lan_name_edit: LineEdit
var net_battle: PBLNetBattleSession
var net_timer_label: Label
var net_connection_label: Label

func _process(delta: float) -> void:
	if net_battle != null and not net_battle.state.is_empty():
		net_battle.tick_action_timer(delta)
		if net_timer_label != null and is_instance_valid(net_timer_label):
			net_timer_label.text = "本回合剩余时间：%d 秒%s" % [net_battle.get_remaining_seconds(), "（房主计时）" if net_battle.is_authority else "（本机显示，房主裁定）"]
		if net_connection_label != null and is_instance_valid(net_connection_label) and lan_network != null:
			net_connection_label.text = "网络连接状态：%s" % lan_network.get_connection_state()

func _ready() -> void:
	_set_theme()
	_load_save()
	lan_network = PBLLanNetwork.new()
	add_child(lan_network)
	lan_network.status_changed.connect(_on_lan_status)
	lan_network.peer_discovered.connect(_on_lan_peer_discovered)
	lan_network.message_received.connect(_on_lan_message)
	lan_network.connection_closed.connect(_on_lan_closed)
	net_battle = PBLNetBattleSession.new()
	net_battle.state_changed.connect(_on_net_battle_state_changed)
	net_battle.action_rejected.connect(_on_net_battle_action_rejected)
	_build_shell()
	_show_page("home")

func _set_theme() -> void:
	var theme := Theme.new()
	theme.default_font_size = 18
	theme.set_color("font_color", "Label", Color("#203a55"))
	theme.set_color("font_color", "Button", Color("#203a55"))
	theme.set_stylebox("normal", "Button", _panel_style(Color("#ffffff"), Color("#c9d9e7"), 12, 10))
	theme.set_stylebox("hover", "Button", _panel_style(Color("#edf6ff"), Color("#79a9d1"), 12, 10))
	theme.set_stylebox("pressed", "Button", _panel_style(Color("#dcecff"), Color("#4c8fc4"), 12, 10))
	theme.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	theme.set_stylebox("normal", "LineEdit", _panel_style(Color("#f7fbff"), Color("#c9d9e7"), 10, 8))
	theme.set_stylebox("normal", "TextEdit", _panel_style(Color("#f7fbff"), Color("#c9d9e7"), 10, 8))
	self.theme = theme

func _panel_style(bg: Color, border: Color, radius: int, margin: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(1)
	s.set_corner_radius_all(radius)
	s.content_margin_left = margin
	s.content_margin_right = margin
	s.content_margin_top = margin
	s.content_margin_bottom = margin
	return s

func _build_shell() -> void:
	var bg := ColorRect.new()
	bg.color = Color("#e8f1f8")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	ui_root = VBoxContainer.new()
	ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_theme_constant_override("separation", 12)
	ui_root.add_theme_constant_override("margin_left", 22)
	ui_root.add_theme_constant_override("margin_right", 22)
	ui_root.add_theme_constant_override("margin_top", 16)
	ui_root.add_theme_constant_override("margin_bottom", 16)
	add_child(ui_root)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 14)
	var brand := Label.new()
	brand.text = "⚔  宝可梦对战实验室重制版"
	brand.add_theme_font_size_override("font_size", 27)
	brand.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(brand)
	var save_btn := Button.new()
	save_btn.text = "保存进度"
	save_btn.pressed.connect(_save_game)
	header.add_child(save_btn)
	var export_btn := Button.new()
	export_btn.text = "导出存档"
	export_btn.pressed.connect(_export_save)
	header.add_child(export_btn)
	var import_btn := Button.new()
	import_btn.text = "导入存档"
	import_btn.pressed.connect(_import_save)
	header.add_child(import_btn)
	ui_root.add_child(header)
	var nav := HBoxContainer.new()
	nav.add_theme_constant_override("separation", 8)
	for item in [{"id":"home","name":"对战大厅"},{"id":"teams","name":"队伍管理"},{"id":"editor","name":"宝可梦编辑"},{"id":"battle","name":"战斗场"},{"id":"dex","name":"属性图鉴"},{"id":"lan","name":"局域网"}]:
		var b := Button.new()
		b.text = item.name
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_show_page.bind(item.id))
		nav.add_child(b)
	ui_root.add_child(nav)
	var card := PanelContainer.new()
	card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	card.add_theme_stylebox_override("panel", _panel_style(Color("#ffffff"), Color("#cbdbe8"), 18, 18))
	ui_root.add_child(card)
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 12)
	card.add_child(inner)
	page_title = Label.new()
	page_title.add_theme_font_size_override("font_size", 24)
	inner.add_child(page_title)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	inner.add_child(scroll)
	content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 10)
	scroll.add_child(content)
	status_label = Label.new()
	status_label.text = "本地存档已启用 · Godot 原生重制工程"
	status_label.add_theme_color_override("font_color", Color("#71879b"))
	ui_root.add_child(status_label)

func _clear_content() -> void:
	for child in content.get_children():
		child.queue_free()

func _show_page(page: String) -> void:
	current_page = page
	_clear_content()
	match page:
		"home":
			page_title.text = "对战大厅"
			_add_label("欢迎来到全新的原生游戏版本。优先适配 Android 横屏设备。", 20)
			_add_label("当前版本：v0.7 房主权威联机战斗原型", 16)
			var row := HBoxContainer.new()
			content.add_child(row)
			_add_action(row, "编辑红方队伍", _show_page.bind("teams"))
			_add_action(row, "创建本地对战", _start_battle)
			_add_action(row, "查看属性图鉴", _show_page.bind("dex"))
			_add_label("功能迁移状态", 20)
			_add_label("已建立：原生主界面、队伍本地存档、宝可梦编辑、属性克制与技能伤害核心。", 16)
			_add_label("已加入：UDP 局域网发现、TCP 房间连接、队伍资料交换；后续完善权威战斗状态同步与重连。", 16)
		"teams": _page_teams()
		"editor": _page_editor()
		"battle": _page_battle()
		"dex": _page_dex()
		"lan": _page_lan()
		"net_battle": _page_net_battle()

func _add_label(text: String, size: int = 16) -> Label:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", size)
	content.add_child(l)
	return l

func _add_action(parent: Control, text: String, action: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(150, 48)
	b.pressed.connect(action)
	parent.add_child(b)
	return b

func _page_teams() -> void:
	page_title.text = "队伍管理 · 每方最多六只"
	for side in ["red", "blue"]:
		var title := Label.new()
		title.text = "红方队伍" if side == "red" else "蓝方队伍"
		title.add_theme_font_size_override("font_size", 20)
		content.add_child(title)
		if teams[side].is_empty():
			_add_label("尚未配置宝可梦。", 14)
		for i in range(teams[side].size()):
			var mon: Dictionary = teams[side][i]
			var row := HBoxContainer.new()
			content.add_child(row)
			var info := Label.new()
			info.text = "%d. %s  [%s]  HP %d / 攻 %d" % [i + 1, mon.get("name", "未命名"), mon.get("type", "一般"), int(mon.get("hp", 1)), int(mon.get("atk", 1))]
			info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			row.add_child(info)
			var edit := Button.new()
			edit.text = "编辑"
			edit.pressed.connect(_begin_edit.bind(side, i))
			row.add_child(edit)
			var remove := Button.new()
			remove.text = "删除"
			remove.pressed.connect(_remove_mon.bind(side, i))
			row.add_child(remove)
		var add := Button.new()
		add.text = "＋ 添加宝可梦"
		add.disabled = teams[side].size() >= 6
		add.pressed.connect(_begin_add.bind(side))
		content.add_child(add)
		content.add_child(HSeparator.new())

func _begin_edit(side: String, index: int) -> void:
	editing_side = side
	editing_index = index
	_show_page("editor")

func _begin_add(side: String) -> void:
	editing_side = side
	editing_index = -1
	_show_page("editor")

func _remove_mon(side: String, index: int) -> void:
	teams[side].remove_at(index)
	_save_game()
	_show_page("teams")

func _page_editor() -> void:
	page_title.text = "宝可梦编辑器 · " + ("编辑现有资料" if editing_index >= 0 else "新增宝可梦")
	var existing: Dictionary = teams[editing_side][editing_index].duplicate(true) if editing_index >= 0 and editing_index < teams[editing_side].size() else {}
	var name_edit := LineEdit.new()
	name_edit.placeholder_text = "宝可梦名称，例如：喷火龙"
	name_edit.text = str(existing.get("name", ""))
	content.add_child(name_edit)
	var type_select := OptionButton.new()
	for t in TYPES:
		type_select.add_item(t)
	var type_index := TYPES.find(str(existing.get("type", "一般")))
	type_select.select(maxi(0, type_index))
	content.add_child(type_select)
	var ability := LineEdit.new()
	ability.placeholder_text = "特性名称（可自定义）"
	ability.text = str(existing.get("ability", ""))
	content.add_child(ability)
	var item_edit := LineEdit.new()
	item_edit.placeholder_text = "携带道具（可选：生命宝珠、达人带、吃剩的东西）"
	item_edit.text = str(existing.get("item", ""))
	content.add_child(item_edit)
	var stat_grid := GridContainer.new()
	stat_grid.columns = 3
	content.add_child(stat_grid)
	var fields := {}
	for key in ["hp", "atk", "def", "spa", "spd", "spe"]:
		var edit := SpinBox.new()
		edit.min_value = 1
		edit.max_value = 255
		edit.value = int(existing.get(key, 80))
		edit.prefix = key.to_upper() + "  "
		stat_grid.add_child(edit)
		fields[key] = edit
	var moves := LineEdit.new()
	moves.placeholder_text = "技能（逗号分隔，最多四个）"
	moves.text = ",".join(PackedStringArray(existing.get("moves", [])))
	content.add_child(moves)
	var save_btn := Button.new()
	save_btn.text = "保存修改" if editing_index >= 0 else "添加到" + ("红方" if editing_side == "red" else "蓝方") + "队伍"
	save_btn.custom_minimum_size.y = 52
	save_btn.pressed.connect(func():
		if name_edit.text.strip_edges().is_empty():
			status_label.text = "请填写宝可梦名称。"
			return
		if editing_index < 0 and teams[editing_side].size() >= 6:
			status_label.text = "该队伍已满六只，请先删除一只。"
			return
		var move_list: Array = []
		for move in moves.text.split(",", false):
			var clean := move.strip_edges()
			if not clean.is_empty(): move_list.append(clean)
		if move_list.is_empty(): move_list = ["撞击"]
		var mon := {"name":name_edit.text.strip_edges(), "type":type_select.get_item_text(type_select.selected), "ability":ability.text.strip_edges(), "item":item_edit.text.strip_edges(), "hp":int(fields.hp.value), "atk":int(fields.atk.value), "def":int(fields.def.value), "spa":int(fields.spa.value), "spd":int(fields.spd.value), "spe":int(fields.spe.value), "moves":move_list.slice(0, 4)}
		if editing_index >= 0 and editing_index < teams[editing_side].size():
			teams[editing_side][editing_index] = mon
		else:
			teams[editing_side].append(mon)
		editing_index = -1
		_save_game()
		_show_page("teams")
	)
	content.add_child(save_btn)
	_add_label("支持自定义名称、属性、特性、六项基础能力值及最多四个技能。", 14)

func _page_battle() -> void:
	page_title.text = "回合制战斗场"
	if battle.is_empty():
		_add_label("准备开始对战。双方队伍至少各需要一只宝可梦。", 18)
		_add_action(content, "开始单打", _start_battle)
		return
	var turn_label := _add_label("第 %d 回合 · 天气：%s · 场地：%s" % [battle.turn, battle.get("weather", "无天气"), battle.get("terrain", "无场地")], 22)
	turn_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var field_row := HBoxContainer.new()
	content.add_child(field_row)
	weather_select = OptionButton.new()
	for weather_name in ["无天气", "大晴天", "下雨"]: weather_select.add_item(weather_name)
	weather_select.select(maxi(0, ["无天气", "大晴天", "下雨"].find(str(battle.get("weather", "无天气")))))
	weather_select.item_selected.connect(func(i): battle.weather = weather_select.get_item_text(i); _show_page("battle"))
	field_row.add_child(weather_select)
	terrain_select = OptionButton.new()
	for terrain_name in ["无场地", "青草场地", "电气场地", "精神场地"]: terrain_select.add_item(terrain_name)
	terrain_select.select(maxi(0, ["无场地", "青草场地", "电气场地", "精神场地"].find(str(battle.get("terrain", "无场地")))))
	terrain_select.item_selected.connect(func(i): battle.terrain = terrain_select.get_item_text(i); _show_page("battle"))
	field_row.add_child(terrain_select)
	turn_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var sides := HBoxContainer.new()
	content.add_child(sides)
	for side in ["red", "blue"]:
		var box := PanelContainer.new()
		box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		sides.add_child(box)
		var col := VBoxContainer.new()
		box.add_child(col)
		var mon: Dictionary = battle[side]
		var title := Label.new()
		title.text = ("红方 · " if side == "red" else "蓝方 · ") + mon.name
		title.add_theme_font_size_override("font_size", 22)
		col.add_child(title)
		var hp := ProgressBar.new()
		hp.max_value = mon.max_hp
		hp.value = mon.hp
		hp.custom_minimum_size.y = 24
		col.add_child(hp)
		var hp_text := Label.new()
		hp_text.text = "HP %d / %d · 状态：%s" % [mon.hp, mon.max_hp, _status_label(str(mon.get("status", "")))]
		col.add_child(hp_text)
	var switch_heading := _add_label("队伍轮换（换人会消耗本回合）", 16)
	var switch_row := HBoxContainer.new()
	content.add_child(switch_row)
	var red_party: Array = battle.get("party_red", [])
	for i in range(red_party.size()):
		var member: Dictionary = red_party[i]
		var switch_btn := Button.new()
		switch_btn.text = "%s%s · %d/%d" % ["▶ " if i == int(battle.get("active_red", 0)) else "", str(member.get("name", "未命名")), int(member.get("hp", 0)), int(member.get("max_hp", member.get("hp", 1)))]
		switch_btn.disabled = i == int(battle.get("active_red", 0)) or int(member.get("hp", 0)) <= 0 or int(battle.red.hp) <= 0 or int(battle.blue.hp) <= 0
		switch_btn.pressed.connect(_switch_red.bind(i))
		switch_row.add_child(switch_btn)
	var action_row := HBoxContainer.new()
	content.add_child(action_row)
	var move_names: Array = battle.red.moves
	for i in range(move_names.size()):
		var move_btn := Button.new()
		var info := PBLBattleEngine.move_info(str(move_names[i]))
		move_btn.text = "%s\n%s / %s" % [str(move_names[i]), str(info.type), ("状态技能" if str(info.category) == "status" else "威力 %d" % int(info.power))]
		move_btn.custom_minimum_size.y = 64
		move_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		move_btn.disabled = int(battle.red.hp) <= 0 or int(battle.blue.hp) <= 0
		move_btn.pressed.connect(_use_move.bind(i))
		action_row.add_child(move_btn)
	_add_label("伤害计入属性克制、天气、场地、特性、道具与命中率；异常状态会在回合结束结算。未收录技能暂按一般属性物理招式处理。", 13)
	var log := RichTextLabel.new()
	log.custom_minimum_size.y = 180
	log.size_flags_vertical = Control.SIZE_EXPAND_FILL
	log.bbcode_enabled = true
	log.text = "\n".join(log_lines)
	content.add_child(log)
	_add_action(content, "结束战斗 / 返回大厅", func():
		battle.clear()
		log_lines.clear()
		_show_page("home")
	)

func _start_battle() -> void:
	if teams.red.is_empty() or teams.blue.is_empty():
		status_label.text = "请先在红方和蓝方各配置至少一只宝可梦。"
		_show_page("teams")
		return
	var red_party: Array = []
	var blue_party: Array = []
	for source in teams.red:
		red_party.append(PBLBattleEngine.prepare_battle_member(source))
	for source in teams.blue:
		blue_party.append(PBLBattleEngine.prepare_battle_member(source))
	var red: Dictionary = red_party[0]
	var blue: Dictionary = blue_party[0]
	battle = {"turn":1, "red":red, "blue":blue, "party_red":red_party, "party_blue":blue_party, "active_red":0, "active_blue":0, "weather":"无天气", "terrain":"无场地"}
	log_lines = ["对战开始！", "%s VS %s" % [red.name, blue.name], "双方队伍：红方 %d 只，蓝方 %d 只。" % [red_party.size(), blue_party.size()]]
	_show_page("battle")

func _switch_red(index: int) -> void:
	if battle.is_empty(): return
	var party: Array = battle.get("party_red", [])
	if index < 0 or index >= party.size() or index == int(battle.get("active_red", 0)):
		return
	if int(party[index].get("hp", 0)) <= 0 or int(battle.red.get("hp", 0)) <= 0:
		return
	var old_name := str(battle.red.get("name", "宝可梦"))
	battle.active_red = index
	battle.red = party[index]
	log_lines.append("红方收回 %s，派出了 %s！本回合主动换人。" % [old_name, battle.red.name])
	# 换人占用玩家行动；蓝方仍会执行一次反击。
	_perform_blue_counter()
	_finish_turn()

func _perform_blue_counter() -> void:
	if battle.is_empty() or int(battle.blue.get("hp", 0)) <= 0 or int(battle.red.get("hp", 0)) <= 0:
		return
	var blue: Dictionary = battle.blue
	var red: Dictionary = battle.red
	if str(blue.get("status", "")) == "sleep" or PBLBattleEngine.paralysis_prevents_action(blue):
		log_lines.append("蓝方的 %s 无法行动。" % blue.name)
		return
	var moves: Array = blue.get("moves", ["撞击"])
	var move_name := str(moves[randi_range(0, moves.size() - 1)]) if not moves.is_empty() else "撞击"
	var result := PBLBattleEngine.calculate_damage(blue, red, move_name, str(battle.weather), str(battle.terrain))
	if result.missed:
		log_lines.append("蓝方的 %s 使用 %s，但是没有命中！" % [blue.name, move_name])
	elif int(result.damage) > 0:
		red.hp = maxi(0, int(red.hp) - int(result.damage))
		log_lines.append("蓝方的 %s 使用 %s，造成 %d 点伤害。" % [blue.name, move_name, int(result.damage)])
	else:
		log_lines.append("蓝方的 %s 使用了 %s，但没有造成伤害。" % [blue.name, move_name])

func _use_move(index: int) -> void:
	if battle.is_empty() or int(battle.blue.hp) <= 0 or int(battle.red.hp) <= 0:
		return
	var red: Dictionary = battle.red
	var blue: Dictionary = battle.blue
	var move_name := str(red.moves[index]) if index < red.moves.size() else "撞击"
	var blue_acts_first := PBLBattleEngine.first_actor_speed(red, blue) == "blue"
	if blue_acts_first:
		log_lines.append("速度判定：蓝方先行动。")
		_perform_blue_counter()
		if int(red.get("hp", 0)) <= 0:
			_finish_turn()
			return
	else:
		log_lines.append("速度判定：红方先行动。")
	if str(red.get("status", "")) == "sleep":
		log_lines.append("红方的 %s 仍在睡眠，无法行动。" % red.name)
		_finish_turn()
		return
	if PBLBattleEngine.paralysis_prevents_action(red):
		log_lines.append("红方的 %s 因麻痹而无法行动。" % red.name)
		_finish_turn()
		return
	var result := PBLBattleEngine.calculate_damage(red, blue, move_name, str(battle.weather), str(battle.terrain))
	var move_info: Dictionary = result.move
	var protected := move_name == "守住"
	if protected:
		log_lines.append("红方的 %s 使用了守住！本回合抵挡反击。" % red.name)
	elif str(move_info.get("effect", "")) in ["paralysis", "bad_poison", "poison", "burn"]:
		var status_name := str(move_info.effect)
		if result.missed:
			log_lines.append("红方使用 %s 但没有命中。" % move_name)
		elif PBLBattleEngine.apply_status(blue, status_name):
			log_lines.append("蓝方的 %s 陷入%s状态。" % [blue.name, _status_label(status_name)])
		else:
			log_lines.append("蓝方的 %s 无法陷入该异常状态。" % blue.name)
	elif str(move_info.get("effect", "")) == "sleep_self":
		red.hp = int(red.max_hp)
		red.status = "sleep"
		red.status_counter = 0
		log_lines.append("红方的 %s 使用睡觉，恢复全部 HP 并进入睡眠。" % red.name)
	elif str(move_info.get("effect", "")) == "heal":
		var healed := mini(int(red.max_hp), int(red.hp) + maxi(1, int(red.max_hp / 2.0))) - int(red.hp)
		red.hp = mini(int(red.max_hp), int(red.hp) + maxi(1, int(red.max_hp / 2.0)))
		log_lines.append("红方的 %s 使用自我再生，恢复 %d HP。" % [red.name, healed])
	elif result.missed:
		log_lines.append("红方的 %s 使用了 %s，但是没有命中！" % [red.name, move_name])
	elif int(result.damage) == 0 and float(result.effectiveness) == 0.0:
		log_lines.append("红方的 %s 使用了 %s，但对蓝方没有效果。" % [red.name, move_name])
	elif int(result.damage) > 0:
		blue.hp = maxi(0, int(blue.hp) - int(result.damage))
		var effect_text := "效果绝佳！" if float(result.effectiveness) > 1.0 else ("效果不佳……" if float(result.effectiveness) < 1.0 else "")
		log_lines.append("红方的 %s 使用 %s（%s），造成 %d 点伤害。%s" % [red.name, move_name, str(move_info.type), int(result.damage), effect_text])
	else:
		log_lines.append("红方的 %s 使用了 %s。" % [red.name, move_name])
	if blue.hp <= 0:
		log_lines.append("蓝方 %s 倒下了！红方获胜。" % blue.name)
		_show_page("battle")
		return
	if not protected and not blue_acts_first:
		_perform_blue_counter()
	if red.hp <= 0:
		log_lines.append("红方 %s 倒下了！蓝方获胜。" % red.name)
	_finish_turn()

func _finish_turn() -> void:
	for side in ["red", "blue"]:
		var mon: Dictionary = battle[side]
		if int(mon.get("hp", 0)) <= 0: continue
		var effect := PBLBattleEngine.end_turn_effect(mon)
		if not str(effect.message).is_empty(): log_lines.append(("红方" if side == "red" else "蓝方") + "的 %s：%s。" % [mon.name, str(effect.message)])
		if int(mon.get("hp", 0)) <= 0: log_lines.append("%s的 %s 因异常状态倒下了。" % ["红方" if side == "red" else "蓝方", mon.name])
	for side in ["red", "blue"]:
		var party_key := "party_red" if side == "red" else "party_blue"
		var active_key := "active_red" if side == "red" else "active_blue"
		var party: Array = battle.get(party_key, [])
		var active_index := int(battle.get(active_key, 0))
		if int(battle[side].get("hp", 0)) <= 0:
			var next_index := PBLBattleEngine.next_healthy_member(party, active_index)
			if next_index >= 0:
				battle[active_key] = next_index
				battle[side] = party[next_index]
				log_lines.append("%s方派出下一只宝可梦：%s！" % ["红" if side == "red" else "蓝", battle[side].name])
			else:
				log_lines.append("%s方队伍全部失去战斗能力。" % ("红" if side == "red" else "蓝"))
	var red_alive := _party_has_healthy(battle.get("party_red", []))
	var blue_alive := _party_has_healthy(battle.get("party_blue", []))
	if not red_alive or not blue_alive:
		log_lines.append("%s获胜！" % ("红方" if red_alive else "蓝方"))
	else:
		battle.turn = int(battle.turn) + 1
	_show_page("battle")

func _party_has_healthy(party: Array) -> bool:
	for mon in party:
		if int(mon.get("hp", 0)) > 0: return true
	return false

func _status_label(status: String) -> String:
	return {"burn":"灼伤", "poison":"中毒", "bad_poison":"剧毒", "paralysis":"麻痹", "sleep":"睡眠"}.get(status, "无")

func _page_dex() -> void:
	page_title.text = "属性图鉴"
	_add_label("18 种属性基础资料", 18)
	var grid := GridContainer.new()
	grid.columns = 6
	content.add_child(grid)
	for t in TYPES:
		var b := Button.new()
		b.text = t
		b.modulate = TYPE_COLORS[t]
		b.custom_minimum_size = Vector2(120, 48)
		b.pressed.connect(_show_type_matchups.bind(t))
		grid.add_child(b)
	_add_label("点击任意属性查看它攻击其他属性时的克制关系。", 14)

func _show_type_matchups(attacking_type: String) -> void:
	var strong: Array[String] = []
	var weak: Array[String] = []
	var immune: Array[String] = []
	for defender_type in TYPES:
		var multiplier := PBLBattleEngine.effectiveness(attacking_type, [defender_type])
		if multiplier == 0.0:
			immune.append(defender_type)
		elif multiplier > 1.0:
			strong.append(defender_type)
		elif multiplier < 1.0:
			weak.append(defender_type)
	status_label.text = "%s属性攻击：\n效果绝佳：%s\n效果不佳：%s\n完全无效：%s" % [attacking_type, "、".join(strong) if not strong.is_empty() else "无", "、".join(weak) if not weak.is_empty() else "无", "、".join(immune) if not immune.is_empty() else "无"]

func _page_lan() -> void:
	page_title.text = "局域网双人对战 · v1.0"
	_add_label("两台 Android 设备连接同一 Wi-Fi。使用 UDP 广播发现房间，TCP 建立点对点连接。", 17)
	_add_label("房主权威单打回合 · 45 秒行动时限 · 客户端断线自动重连（最多 12 次）。", 14)
	lan_name_edit = LineEdit.new()
	lan_name_edit.placeholder_text = "训练家名称"
	lan_name_edit.text = "训练家"
	content.add_child(lan_name_edit)
	var actions := HBoxContainer.new()
	content.add_child(actions)
	_add_action(actions, "搜索附近玩家", _start_lan_discovery)
	_add_action(actions, "创建房间", _host_lan_room)
	_add_action(actions, "断开 / 停止搜索", func(): lan_network.disconnect_peer(); _show_page("lan"))
	lan_status_label = _add_label("网络状态：未连接。", 16)
	_add_label("发现的房间（点击即可加入）", 18)
	lan_peers_box = VBoxContainer.new()
	content.add_child(lan_peers_box)
	_add_label("手动输入房主 IPv4 地址", 16)
	lan_ip_edit = LineEdit.new()
	lan_ip_edit.placeholder_text = "例如 192.168.1.23"
	content.add_child(lan_ip_edit)
	_add_action(content, "连接此地址", _join_lan_ip)
	_add_action(content, "返回大厅", _show_page.bind("home"))
	if lan_network.get_connection_state() != "offline":
		lan_status_label.text = "网络状态：" + lan_network.get_connection_state()
	if lan_network.get_connection_state() == "connected":
		if lan_network.is_host:
			_add_action(content, "房主：开始权威联机战斗", _start_online_battle)
		else:
			_add_action(content, "进入联机战斗等待房主", _enter_online_battle_wait)
	for peer_ip in lan_network.discovered:
		_add_lan_peer_button(lan_network.discovered[peer_ip])

func _local_player_name() -> String:
	return lan_name_edit.text.strip_edges() if lan_name_edit != null else "训练家"

func _start_lan_discovery() -> void:
	lan_network.start_discovery(_local_player_name(), teams.red)

func _host_lan_room() -> void:
	lan_network.host_room(_local_player_name(), teams.red)

func _join_lan_ip() -> void:
	if lan_ip_edit == null or lan_ip_edit.text.strip_edges().is_empty():
		status_label.text = "请先输入房主的局域网 IP 地址。"
		return
	lan_network.join_room(lan_ip_edit.text, _local_player_name(), teams.red)

func _on_lan_status(message: String) -> void:
	status_label.text = message
	if lan_network != null and lan_network.is_host and net_battle != null and not net_battle.state.is_empty() and message.contains("队伍资料交换完成"):
		lan_network.send_message("battle_snapshot", {"snapshot":net_battle.make_snapshot()})
	if lan_status_label != null and is_instance_valid(lan_status_label):
		lan_status_label.text = "网络状态：" + message
	if current_page == "lan" and message.contains("队伍资料交换完成"):
		_show_page("lan")

func _on_lan_peer_discovered(peer: Dictionary) -> void:
	if current_page == "lan" and lan_peers_box != null and is_instance_valid(lan_peers_box):
		for child in lan_peers_box.get_children():
			if child is Button and str(child.get_meta("peer_ip", "")) == str(peer.ip):
				child.queue_free()
		_add_lan_peer_button(peer)

func _add_lan_peer_button(peer: Dictionary) -> void:
	if lan_peers_box == null or not is_instance_valid(lan_peers_box): return
	var button := Button.new()
	button.text = "%s  ·  %s  ·  队伍 %d 只" % [str(peer.get("name", "训练家")), str(peer.get("ip", "")), int(peer.get("players", 0))]
	button.set_meta("peer_ip", str(peer.get("ip", "")))
	button.pressed.connect(func():
		if lan_ip_edit != null: lan_ip_edit.text = str(peer.get("ip", ""))
		lan_network.join_room(str(peer.get("ip", "")), _local_player_name(), teams.red)
	)
	lan_peers_box.add_child(button)

func _on_lan_message(message: Dictionary) -> void:
	var kind := str(message.get("kind", ""))
	if kind == "battle_action" and lan_network.is_host:
		if net_battle.receive_remote_action(message):
			status_label.text = "收到对手行动，房主正在结算。"
	elif kind == "battle_snapshot" and not lan_network.is_host:
		# The host may start the match before the guest taps the "wait for host"
		# button. Initialize the replica role on the first snapshot so the guest
		# is always blue, regardless of which UI event happens first.
		if net_battle.state.is_empty():
			net_battle.start_replica()
		if net_battle.apply_authoritative_snapshot(message.get("snapshot", {}), lan_network.reconnected_this_connection):
			lan_network.reconnected_this_connection = false
			_show_page("net_battle")
	else:
		status_label.text = "收到联机消息：%s" % kind

func _start_online_battle() -> void:
	if not lan_network.is_host or lan_network.remote_team.is_empty():
		_on_lan_status("需要房主身份，并等待对方队伍资料交换完成。")
		return
	var result := net_battle.start_authority(teams.red, lan_network.remote_team)
	if not bool(result.get("ok", false)):
		_on_lan_status(str(result.get("error", "无法开始联机战斗。")))
		return
	lan_network.send_message("battle_snapshot", {"snapshot":result.snapshot})
	_show_page("net_battle")

func _enter_online_battle_wait() -> void:
	net_battle.start_replica()
	_show_page("net_battle")

func _page_net_battle() -> void:
	page_title.text = "局域网实时回合战斗 · v1.0 房主权威模式"
	if net_battle.state.is_empty():
		_add_label("等待房主发送战斗初始状态。请保持 TCP 连接，不要关闭游戏。", 18)
		_add_action(content, "返回局域网页面", _show_page.bind("lan"))
		return
	var state: Dictionary = net_battle.state
	_add_label("第 %d 回合 · 你的阵营：%s · %s" % [int(state.get("turn", 1)), "红方（房主）" if net_battle.local_side == "red" else "蓝方（挑战者）", "战斗结束" if not str(state.get("winner", "")).is_empty() else "进行中"], 20)
	net_timer_label = _add_label("本回合剩余时间：%d 秒" % net_battle.get_remaining_seconds(), 16)
	net_connection_label = _add_label("网络连接状态：%s" % lan_network.get_connection_state(), 14)
	for side in ["red", "blue"]:
		var party: Array = state.get("party_red", []) if side == "red" else state.get("party_blue", [])
		var index := int(state.get("active_red", 0) if side == "red" else state.get("active_blue", 0))
		var mon: Dictionary = party[index]
		_add_label("%s方：%s  HP %d/%d  状态：%s" % ["红" if side == "red" else "蓝", mon.get("name", "宝可梦"), int(mon.get("hp", 0)), int(mon.get("max_hp", mon.get("hp", 1))), _status_label(str(mon.get("status", "")))], 17)
	var winner := str(state.get("winner", ""))
	if winner.is_empty():
		if net_battle.local_action_pending:
			_add_label("行动已提交，等待对手选择……", 16)
		else:
			var own_side := net_battle.local_side
			var own_party: Array = state.get("party_red", []) if own_side == "red" else state.get("party_blue", [])
			var own_index := int(state.get("active_red", 0) if own_side == "red" else state.get("active_blue", 0))
			var own_mon: Dictionary = own_party[own_index]
			_add_label("选择本回合行动：", 17)
			var moves: Array = own_mon.get("moves", ["撞击"])
			for i in range(moves.size()):
				_add_action(content, "使用技能：" + str(moves[i]), _submit_online_action.bind({"type":"move", "index":i}))
			var switch_row := HBoxContainer.new()
			content.add_child(switch_row)
			for i in range(own_party.size()):
				if i == own_index or int(own_party[i].get("hp", 0)) <= 0: continue
				_add_action(switch_row, "换上 " + str(own_party[i].get("name", "宝可梦")), _submit_online_action.bind({"type":"switch", "index":i}))
	else:
		_add_label("胜者：%s" % ("房主红方" if winner == "red" else "挑战者蓝方" if winner == "blue" else "平局"), 20)
	_add_label("战斗日志", 17)
	var logs: Array = state.get("logs", [])
	for line in logs.slice(maxi(0, logs.size() - 12), logs.size()):
		_add_label(str(line), 14)
	_add_action(content, "返回局域网页面", _show_page.bind("lan"))

func _submit_online_action(action: Dictionary) -> void:
	if not net_battle.submit_local_action(action):
		return
	if not net_battle.is_authority:
		var packet := net_battle.make_client_action_packet()
		if not lan_network.send_message("battle_action", packet):
			net_battle.local_action_pending = false
			_on_lan_status("行动发送失败，连接可能已断开。")
			return
	_show_page("net_battle")

func _on_net_battle_state_changed(snapshot: Dictionary) -> void:
	if lan_network != null and lan_network.is_host:
		lan_network.send_message("battle_snapshot", {"snapshot":snapshot})
	if current_page == "net_battle":
		_show_page("net_battle")

func _on_net_battle_action_rejected(reason: String) -> void:
	_on_lan_status(reason)

func _on_lan_closed(reason: String) -> void:
	_on_lan_status(reason)

func _save_game() -> void:
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		status_label.text = "存档失败：无法写入本地文件。"
		return
	file.store_string(JSON.stringify({"version":1,"teams":teams}, "\t"))
	status_label.text = "本地存档已保存。"

func _load_save() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		teams.red = [_default_mon("喷火龙", "火", 78, 84, 78, ["喷射火焰", "龙爪", "空气斩", "守住"])]
		teams.blue = [_default_mon("水箭龟", "水", 79, 83, 100, ["水炮", "冰冻光束", "波导弹", "守住"])]
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null: return
	var parsed = JSON.parse_string(file.get_as_text())
	if parsed is Dictionary and parsed.get("teams") is Dictionary:
		var loaded: Dictionary = parsed.teams
		var red_data = loaded.get("red", [])
		var blue_data = loaded.get("blue", [])
		if red_data is Array and blue_data is Array:
			teams = {"red": red_data.slice(0, 6), "blue": blue_data.slice(0, 6)}

func _default_mon(mon_name: String, mon_type: String, hp: int, atk: int, defense: int, moves: Array) -> Dictionary:
	return {"name":mon_name,"type":mon_type,"ability":"普通特性","hp":hp,"atk":atk,"def":defense,"spa":80,"spd":80,"spe":80,"moves":moves}


func _export_save() -> void:
	var json_text := JSON.stringify({"version": 1, "teams": teams}, "\t")
	var path := OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS).path_join("PBL_Remake_Save.json")
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		status_label.text = "导出失败：无法写入文档目录。"
		return
	file.store_string(json_text)
	status_label.text = "存档已导出到文档目录：PBL_Remake_Save.json"

func _import_save() -> void:
	var dialog := FileDialog.new()
	dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	dialog.access = FileDialog.ACCESS_FILESYSTEM
	dialog.add_filter("*.json", "JSON 存档")
	dialog.file_selected.connect(_load_external_save)
	add_child(dialog)
	dialog.popup_centered_ratio(0.8)

func _load_external_save(path: String) -> void:
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		status_label.text = "导入失败：无法读取文件。"
		return
	var parsed = JSON.parse_string(file.get_as_text())
	if not (parsed is Dictionary and parsed.get("teams") is Dictionary):
		status_label.text = "导入失败：存档格式不正确。"
		return
	var incoming: Dictionary = parsed.teams
	if not (incoming.get("red", []) is Array and incoming.get("blue", []) is Array):
		status_label.text = "导入失败：队伍数据无效。"
		return
	if incoming.red.size() > 6 or incoming.blue.size() > 6:
		status_label.text = "导入失败：每方最多六只宝可梦。"
		return
	teams = {"red": incoming.red, "blue": incoming.blue}
	_save_game()
	_show_page("teams")
	status_label.text = "存档导入成功。"
