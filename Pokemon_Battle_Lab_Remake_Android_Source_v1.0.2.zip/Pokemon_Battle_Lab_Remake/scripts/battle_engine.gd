class_name PBLBattleEngine
extends RefCounted

const TYPE_CHART := {
	"一般": {"岩石":0.5, "幽灵":0.0, "钢":0.5},
	"火": {"火":0.5, "水":0.5, "草":2.0, "冰":2.0, "虫":2.0, "岩石":0.5, "龙":0.5, "钢":2.0},
	"水": {"火":2.0, "水":0.5, "草":0.5, "地面":2.0, "岩石":2.0, "龙":0.5},
	"电": {"水":2.0, "电":0.5, "草":0.5, "地面":0.0, "飞行":2.0, "龙":0.5},
	"草": {"火":0.5, "水":2.0, "草":0.5, "毒":0.5, "地面":2.0, "飞行":0.5, "虫":0.5, "岩石":2.0, "龙":0.5, "钢":0.5},
	"冰": {"火":0.5, "水":0.5, "草":2.0, "冰":0.5, "地面":2.0, "飞行":2.0, "龙":2.0, "钢":0.5},
	"格斗": {"一般":2.0, "冰":2.0, "毒":0.5, "飞行":0.5, "超能力":0.5, "虫":0.5, "岩石":2.0, "幽灵":0.0, "恶":2.0, "钢":2.0, "妖精":0.5},
	"毒": {"草":2.0, "毒":0.5, "地面":0.5, "岩石":0.5, "幽灵":0.5, "钢":0.0, "妖精":2.0},
	"地面": {"火":2.0, "电":2.0, "草":0.5, "毒":2.0, "飞行":0.0, "虫":0.5, "岩石":2.0, "钢":2.0},
	"飞行": {"电":0.5, "草":2.0, "格斗":2.0, "虫":2.0, "岩石":0.5, "钢":0.5},
	"超能力": {"格斗":2.0, "毒":2.0, "超能力":0.5, "恶":0.0, "钢":0.5},
	"虫": {"火":0.5, "草":2.0, "格斗":0.5, "毒":0.5, "飞行":0.5, "超能力":2.0, "幽灵":0.5, "恶":2.0, "钢":0.5, "妖精":0.5},
	"岩石": {"火":2.0, "冰":2.0, "格斗":0.5, "地面":0.5, "飞行":2.0, "虫":2.0, "钢":0.5},
	"幽灵": {"一般":0.0, "超能力":2.0, "幽灵":2.0, "恶":0.5},
	"龙": {"龙":2.0, "钢":0.5, "妖精":0.0},
	"恶": {"格斗":0.5, "超能力":2.0, "幽灵":2.0, "恶":0.5, "妖精":0.5},
	"钢": {"火":0.5, "水":0.5, "电":0.5, "冰":2.0, "岩石":2.0, "钢":0.5, "妖精":2.0},
	"妖精": {"火":0.5, "格斗":2.0, "毒":0.5, "龙":2.0, "恶":2.0, "钢":0.5}
}

const MOVE_DATA := {
	"撞击": {"type":"一般", "power":40, "category":"physical", "accuracy":100},
	"喷射火焰": {"type":"火", "power":90, "category":"special", "accuracy":100},
	"火焰放射": {"type":"火", "power":90, "category":"special", "accuracy":100},
	"水炮": {"type":"水", "power":110, "category":"special", "accuracy":80},
	"水之波动": {"type":"水", "power":60, "category":"special", "accuracy":100},
	"十万伏特": {"type":"电", "power":90, "category":"special", "accuracy":100},
	"雷电": {"type":"电", "power":110, "category":"special", "accuracy":70},
	"能量球": {"type":"草", "power":90, "category":"special", "accuracy":100},
	"日光束": {"type":"草", "power":120, "category":"special", "accuracy":100},
	"冰冻光束": {"type":"冰", "power":90, "category":"special", "accuracy":100},
	"急冻光线": {"type":"冰", "power":90, "category":"special", "accuracy":100},
	"近身战": {"type":"格斗", "power":120, "category":"physical", "accuracy":100},
	"波导弹": {"type":"格斗", "power":80, "category":"special", "accuracy":100},
	"污泥炸弹": {"type":"毒", "power":90, "category":"special", "accuracy":100},
	"地震": {"type":"地面", "power":100, "category":"physical", "accuracy":100},
	"空气斩": {"type":"飞行", "power":75, "category":"special", "accuracy":95},
	"精神强念": {"type":"超能力", "power":90, "category":"special", "accuracy":100},
	"虫鸣": {"type":"虫", "power":90, "category":"special", "accuracy":100},
	"岩崩": {"type":"岩石", "power":75, "category":"physical", "accuracy":90},
	"暗影球": {"type":"幽灵", "power":80, "category":"special", "accuracy":100},
	"龙爪": {"type":"龙", "power":80, "category":"physical", "accuracy":100},
	"恶之波动": {"type":"恶", "power":80, "category":"special", "accuracy":100},
	"铁头": {"type":"钢", "power":80, "category":"physical", "accuracy":100},
	"魔法闪耀": {"type":"妖精", "power":80, "category":"special", "accuracy":100},
	"守住": {"type":"一般", "power":0, "category":"status", "accuracy":100, "effect":"protect"},
	"电磁波": {"type":"电", "power":0, "category":"status", "accuracy":90, "effect":"paralysis"},
	"剧毒": {"type":"毒", "power":0, "category":"status", "accuracy":90, "effect":"bad_poison"},
	"毒粉": {"type":"毒", "power":0, "category":"status", "accuracy":75, "effect":"poison"},
	"鬼火": {"type":"火", "power":0, "category":"status", "accuracy":85, "effect":"burn"},
	"睡觉": {"type":"超能力", "power":0, "category":"status", "accuracy":100, "effect":"sleep_self"},
	"自我再生": {"type":"一般", "power":0, "category":"status", "accuracy":100, "effect":"heal"}
}


static func effective_speed(mon: Dictionary) -> int:
	var speed := maxi(1, int(mon.get("spe", 80)))
	if str(mon.get("status", "")) == "paralysis":
		speed = maxi(1, int(floor(speed * 0.5)))
	return speed

static func first_actor_speed(red: Dictionary, blue: Dictionary) -> String:
	var red_speed := effective_speed(red)
	var blue_speed := effective_speed(blue)
	if red_speed > blue_speed:
		return "red"
	if blue_speed > red_speed:
		return "blue"
	return "tie"

static func prepare_battle_member(source: Dictionary) -> Dictionary:
	var mon := source.duplicate(true)
	mon["max_hp"] = maxi(1, int(mon.get("max_hp", mon.get("hp", 1))))
	mon["hp"] = clampi(int(mon.get("hp", mon.max_hp)), 0, int(mon.max_hp))
	mon["status"] = str(mon.get("status", ""))
	mon["status_counter"] = int(mon.get("status_counter", 0))
	if not (mon.get("moves", []) is Array) or mon.get("moves", []).is_empty():
		mon["moves"] = ["撞击"]
	return mon

static func next_healthy_member(party: Array, current_index: int) -> int:
	for offset in range(1, party.size() + 1):
		var index := (current_index + offset) % party.size()
		if int(party[index].get("hp", 0)) > 0:
			return index
	return -1

static func move_info(move_name: String) -> Dictionary:
	if MOVE_DATA.has(move_name):
		return MOVE_DATA[move_name].duplicate(true)
	return {"type":"一般", "power":50, "category":"physical", "accuracy":100}

static func effectiveness(move_type: String, defender_types: Array) -> float:
	var multiplier := 1.0
	var chart: Dictionary = TYPE_CHART.get(move_type, {})
	for defender_type in defender_types:
		multiplier *= float(chart.get(str(defender_type), 1.0))
	return multiplier

static func calculate_damage(attacker: Dictionary, defender: Dictionary, move_name: String, weather: String = "无天气", terrain: String = "无场地") -> Dictionary:
	var move := move_info(move_name)
	if str(move.category) == "status" or int(move.power) <= 0:
		var status_missed := randf() > float(move.accuracy) / 100.0
		return {"damage":0, "effectiveness":1.0, "move":move, "missed":status_missed}
	if randf() > float(move.accuracy) / 100.0:
		return {"damage":0, "effectiveness":1.0, "move":move, "missed":true}
	var attack_key := "spa" if move.category == "special" else "atk"
	var defense_key := "spd" if move.category == "special" else "def"
	var attack_stat := maxi(1, int(attacker.get(attack_key, 80)))
	var defense_stat := maxi(1, int(defender.get(defense_key, 80)))
	var ability := str(defender.get("ability", ""))
	var move_type := str(move.type)
	if (move_type == "火" and ability == "引火") or (move_type == "水" and ability == "储水") or (move_type == "电" and ability == "蓄电") or (move_type == "草" and ability == "食草"):
		return {"damage":0, "effectiveness":0.0, "move":move, "missed":false, "ability_block":ability}
	var level := float(attacker.get("level", 50))
	var base_damage := (((2.0 * level / 5.0 + 2.0) * float(move.power) * float(attack_stat) / float(defense_stat)) / 50.0) + 2.0
	var attacker_types: Array = attacker.get("types", [str(attacker.get("type", "一般"))])
	var stab := 1.5 if attacker_types.has(move_type) or str(attacker.get("type", "")) == move_type else 1.0
	var defender_types: Array = defender.get("types", [str(defender.get("type", "一般"))])
	var type_multiplier := effectiveness(move_type, defender_types)
	var weather_multiplier := weather_damage_multiplier(move_type, weather)
	var terrain_multiplier := terrain_move_multiplier(move_type, terrain, bool(attacker.get("grounded", true)))
	var item_multiplier := 1.3 if str(attacker.get("item", "")) == "生命宝珠" else (1.1 if str(attacker.get("item", "")) == "达人带" and type_multiplier > 1.0 else 1.0)
	var low_hp := int(attacker.get("hp", 1)) * 3 <= int(attacker.get("max_hp", attacker.get("hp", 1)))
	var ability_multiplier := 1.3 if low_hp and ((move_type == "火" and str(attacker.get("ability", "")) == "猛火") or (move_type == "水" and str(attacker.get("ability", "")) == "激流")) else 1.0
	if str(attacker.get("status", "")) == "burn" and move.category == "physical": attack_stat = maxi(1, int(attack_stat / 2))
	base_damage = (((2.0 * level / 5.0 + 2.0) * float(move.power) * float(attack_stat) / float(defense_stat)) / 50.0) + 2.0
	var random_factor := randf_range(0.85, 1.0)
	var damage := maxi(1, int(floor(base_damage * stab * type_multiplier * weather_multiplier * terrain_multiplier * item_multiplier * ability_multiplier * random_factor))) if type_multiplier > 0.0 else 0
	return {"damage":damage, "effectiveness":type_multiplier, "stab":stab, "weather_multiplier":weather_multiplier, "terrain_multiplier":terrain_multiplier, "move":move, "missed":false}

static func weather_damage_multiplier(move_type: String, weather: String) -> float:
	if weather == "大晴天":
		if move_type == "火": return 1.5
		if move_type == "水": return 0.5
	elif weather == "下雨":
		if move_type == "水": return 1.5
		if move_type == "火": return 0.5
	return 1.0

static func terrain_move_multiplier(move_type: String, terrain: String, grounded: bool = true) -> float:
	if not grounded: return 1.0
	if terrain == "青草场地" and move_type == "草": return 1.3
	if terrain == "电气场地" and move_type == "电": return 1.3
	if terrain == "精神场地" and move_type == "超能力": return 1.3
	return 1.0

static func can_receive_status(mon: Dictionary, status: String) -> bool:
	if str(mon.get("status", "")) != "": return false
	var types: Array = mon.get("types", [str(mon.get("type", "一般"))])
	if status in ["poison", "bad_poison"] and (types.has("毒") or types.has("钢") or str(mon.get("ability", "")) == "免疫"): return false
	if status == "burn" and (types.has("火") or str(mon.get("ability", "")) == "水幕"): return false
	if status == "paralysis" and (types.has("电") or str(mon.get("ability", "")) == "柔软"): return false
	if status == "sleep" and str(mon.get("ability", "")) == "不眠": return false
	return true

static func apply_status(mon: Dictionary, status: String) -> bool:
	if not can_receive_status(mon, status): return false
	mon["status"] = status
	mon["status_counter"] = 0
	return true

static func end_turn_effect(mon: Dictionary) -> Dictionary:
	var status := str(mon.get("status", ""))
	var damage := 0
	var message := ""
	var max_hp := int(mon.get("max_hp", mon.get("hp", 1)))
	if status == "burn":
		damage = maxi(1, int(max_hp / 16.0))
		message = "受到灼伤伤害"
	elif status == "poison":
		damage = maxi(1, int(max_hp / 8.0))
		message = "受到中毒伤害"
	elif status == "bad_poison":
		mon["status_counter"] = mini(15, int(mon.get("status_counter", 0)) + 1)
		damage = maxi(1, int(max_hp * int(mon.status_counter) / 16.0))
		message = "受到剧毒伤害"
	elif status == "sleep":
		mon["status_counter"] = int(mon.get("status_counter", 0)) + 1
		if int(mon.status_counter) >= 2:
			mon["status"] = ""
			mon["status_counter"] = 0
			message = "从睡眠中醒来了"
	elif status == "paralysis":
		message = "处于麻痹状态"
	if damage > 0: mon["hp"] = maxi(0, int(mon.get("hp", 0)) - damage)
	if str(mon.get("item", "")) == "吃剩的东西" and int(mon.get("hp", 0)) > 0 and int(mon.get("hp", 0)) < max_hp:
		var heal := maxi(1, int(max_hp / 16.0))
		mon["hp"] = mini(max_hp, int(mon.hp) + heal)
		message += "；吃剩的东西恢复了 %d HP" % heal
	return {"damage":damage, "message":message}

static func paralysis_prevents_action(mon: Dictionary) -> bool:
	return str(mon.get("status", "")) == "paralysis" and randf() < 0.25
