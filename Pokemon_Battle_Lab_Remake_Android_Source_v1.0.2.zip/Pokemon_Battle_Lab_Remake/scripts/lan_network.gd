extends Node
class_name PBLLanNetwork

signal status_changed(message: String)
signal peer_discovered(peer: Dictionary)
signal message_received(message: Dictionary)
signal connection_closed(reason: String)

const DISCOVERY_PORT := 38191
const GAME_PORT := 38192
const DISCOVERY_INTERVAL := 2.0
const PROTOCOL_VERSION := 3
const MAX_PACKET_BYTES := 262144
const MAX_RX_BUFFER_BYTES := 524288

var udp := PacketPeerUDP.new()
var tcp_server := TCPServer.new()
var tcp_peer: StreamPeerTCP
var udp_ready := false
var is_host := false
var is_searching := false
var local_name := "训练家"
var local_team: Array = []
var remote_name := ""
var remote_team: Array = []
var discovered: Dictionary = {}
var rx_buffer := ""
var discovery_elapsed := 0.0
var connection_state := "offline"
var last_host_ip := ""
var reconnect_enabled := false
var reconnect_elapsed := 0.0
var reconnect_attempts := 0
var reconnected_this_connection := false
const RECONNECT_INTERVAL := 2.0
const MAX_RECONNECT_ATTEMPTS := 12

func _process(delta: float) -> void:
	if reconnect_enabled and not is_host and tcp_peer == null and not last_host_ip.is_empty():
		reconnect_elapsed += delta
		if reconnect_elapsed >= RECONNECT_INTERVAL:
			reconnect_elapsed = 0.0
			_attempt_reconnect()
	if is_searching:
		discovery_elapsed += delta
		if discovery_elapsed >= DISCOVERY_INTERVAL:
			discovery_elapsed = 0.0
			_broadcast_presence()
		_poll_discovery()
	if is_host:
		_poll_server()
	if tcp_peer != null:
		_poll_tcp()

func start_discovery(player_name: String, team: Array) -> bool:
	local_name = player_name.strip_edges() if not player_name.strip_edges().is_empty() else "训练家"
	local_team = team.duplicate(true)
	if not udp_ready:
		var err := udp.bind(DISCOVERY_PORT, "0.0.0.0")
		if err != OK:
			status_changed.emit("局域网搜索启动失败，UDP 端口 %d 不可用（错误 %d）。" % [DISCOVERY_PORT, err])
			return false
		udp.set_broadcast_enabled(true)
		udp_ready = true
	is_searching = true
	discovered.clear()
	discovery_elapsed = DISCOVERY_INTERVAL
	_broadcast_presence()
	status_changed.emit("正在搜索同一 Wi-Fi 下的玩家……")
	return true

func stop_discovery() -> void:
	is_searching = false
	if udp_ready:
		udp.close()
		udp_ready = false

func host_room(player_name: String, team: Array) -> bool:
	local_name = player_name.strip_edges() if not player_name.strip_edges().is_empty() else "房主"
	local_team = team.duplicate(true)
	if not start_discovery(local_name, local_team):
		return false
	var err := tcp_server.listen(GAME_PORT, "0.0.0.0")
	if err != OK:
		stop_discovery()
		status_changed.emit("创建房间失败，TCP 端口 %d 不可用（错误 %d）。" % [GAME_PORT, err])
		return false
	is_host = true
	connection_state = "hosting"
	status_changed.emit("房间已创建，等待另一台设备加入。端口：%d" % GAME_PORT)
	return true

func join_room(ip: String, player_name: String, team: Array) -> bool:
	stop_discovery()
	last_host_ip = ip.strip_edges()
	reconnected_this_connection = false
	reconnect_enabled = true
	reconnect_attempts = 0
	reconnect_elapsed = 0.0
	local_name = player_name.strip_edges() if not player_name.strip_edges().is_empty() else "挑战者"
	local_team = team.duplicate(true)
	rx_buffer = ""
	tcp_peer = StreamPeerTCP.new()
	var err := tcp_peer.connect_to_host(last_host_ip, GAME_PORT)
	if err != OK:
		tcp_peer = null
		connection_state = "reconnecting"
		status_changed.emit("首次连接请求失败：%s（错误 %d），将自动重试。" % [last_host_ip, err])
		return false
	is_host = false
	connection_state = "connecting"
	status_changed.emit("正在连接 %s:%d……" % [ip, GAME_PORT])
	return true

func _attempt_reconnect() -> void:
	if reconnect_attempts >= MAX_RECONNECT_ATTEMPTS:
		reconnect_enabled = false
		connection_state = "offline"
		status_changed.emit("自动重连已达到 %d 次上限，请手动重新加入房间。" % MAX_RECONNECT_ATTEMPTS)
		return
	reconnect_attempts += 1
	reconnected_this_connection = true
	rx_buffer = ""
	tcp_peer = StreamPeerTCP.new()
	var err := tcp_peer.connect_to_host(last_host_ip, GAME_PORT)
	if err != OK:
		tcp_peer = null
		status_changed.emit("自动重连第 %d/%d 次失败，稍后重试……" % [reconnect_attempts, MAX_RECONNECT_ATTEMPTS])
		return
	connection_state = "reconnecting"
	status_changed.emit("正在自动重连房主 %s（%d/%d）……" % [last_host_ip, reconnect_attempts, MAX_RECONNECT_ATTEMPTS])

func _poll_server() -> void:
	if tcp_peer == null and tcp_server.is_connection_available():
		tcp_peer = tcp_server.take_connection()
		rx_buffer = ""
		connection_state = "connected"
		status_changed.emit("玩家已连接，正在交换队伍资料……")
		_send_packet({"kind":"hello", "protocol":PROTOCOL_VERSION, "name":local_name, "team":local_team})

func _poll_tcp() -> void:
	tcp_peer.poll()
	var state := tcp_peer.get_status()
	if state == StreamPeerTCP.STATUS_ERROR or state == StreamPeerTCP.STATUS_NONE:
		var old_state := connection_state
		tcp_peer = null
		if old_state != "offline":
			if not is_host and reconnect_enabled and not last_host_ip.is_empty():
				connection_state = "reconnecting"
				reconnect_elapsed = 0.0
				status_changed.emit("网络连接中断，正在准备自动重连……")
			else:
				connection_state = "offline"
			connection_closed.emit("网络连接已断开。")
		return
	if state == StreamPeerTCP.STATUS_CONNECTED and connection_state in ["connecting", "reconnecting"]:
		connection_state = "connected"
		status_changed.emit("已连接房主，正在交换队伍资料……")
		_send_packet({"kind":"hello", "protocol":PROTOCOL_VERSION, "name":local_name, "team":local_team})
	var available := tcp_peer.get_available_bytes()
	if available <= 0:
		return
	var result := tcp_peer.get_data(available)
	if result[0] != OK:
		return
	rx_buffer += (result[1] as PackedByteArray).get_string_from_utf8()
	if rx_buffer.to_utf8_buffer().size() > MAX_RX_BUFFER_BYTES:
		disconnect_peer()
		connection_closed.emit("收到的数据超过安全缓冲区上限，连接已关闭。")
		return
	while rx_buffer.contains("\n"):
		var split_at := rx_buffer.find("\n")
		var line := rx_buffer.substr(0, split_at)
		rx_buffer = rx_buffer.substr(split_at + 1)
		if line.to_utf8_buffer().size() > MAX_PACKET_BYTES:
			disconnect_peer()
			connection_closed.emit("单条网络消息超过安全上限，连接已关闭。")
			return
		var parsed = JSON.parse_string(line)
		if parsed is Dictionary:
			_handle_packet(parsed)
		elif not line.strip_edges().is_empty():
			status_changed.emit("收到格式错误的网络消息，已忽略。")

func _handle_packet(packet: Dictionary) -> void:
	var kind := str(packet.get("kind", ""))
	if kind == "hello":
		if int(packet.get("protocol", -1)) != PROTOCOL_VERSION:
			_send_packet({"kind":"error", "message":"协议版本不一致，请更新到相同版本。"})
			return
		remote_name = str(packet.get("name", "对手")).left(40)
		var incoming = packet.get("team", [])
		if not (incoming is Array) or incoming.is_empty():
			_send_packet({"kind":"error", "message":"队伍数据无效，至少需要一只宝可梦。"})
			return
		remote_team = _sanitize_team(incoming)
		if remote_team.is_empty():
			_send_packet({"kind":"error", "message":"队伍数据未通过验证。"})
			return
		reconnect_attempts = 0
		reconnect_elapsed = 0.0
		connection_state = "connected"
		_send_packet({"kind":"hello_ack", "protocol":PROTOCOL_VERSION, "name":local_name, "team":local_team})
		status_changed.emit("已连接：%s。双方队伍资料交换完成。" % remote_name)
	elif kind == "hello_ack":
		if int(packet.get("protocol", -1)) != PROTOCOL_VERSION:
			status_changed.emit("对方协议版本不一致。")
			return
		remote_name = str(packet.get("name", "对手")).left(40)
		var incoming = packet.get("team", [])
		if not (incoming is Array) or incoming.is_empty():
			status_changed.emit("对方队伍数据无效。")
			return
		remote_team = _sanitize_team(incoming)
		if remote_team.is_empty():
			status_changed.emit("对方队伍数据未通过验证。")
			return
		reconnect_attempts = 0
		reconnect_elapsed = 0.0
		connection_state = "connected"
		status_changed.emit("已连接：%s。双方队伍资料交换完成。" % remote_name)
	elif kind == "error":
		status_changed.emit("对战连接错误：%s" % str(packet.get("message", "未知错误")))
	else:
		message_received.emit(packet)

func send_message(kind: String, payload: Dictionary = {}) -> bool:
	if tcp_peer == null or tcp_peer.get_status() != StreamPeerTCP.STATUS_CONNECTED:
		return false
	var packet := payload.duplicate(true)
	packet["kind"] = kind
	return _send_packet(packet)

func _send_packet(packet: Dictionary) -> bool:
	if tcp_peer == null or tcp_peer.get_status() != StreamPeerTCP.STATUS_CONNECTED:
		return false
	var bytes := (JSON.stringify(packet) + "\n").to_utf8_buffer()
	if bytes.size() > MAX_PACKET_BYTES:
		status_changed.emit("发送失败：网络消息超过安全上限。")
		return false
	var err := tcp_peer.put_data(bytes)
	if err != OK:
		status_changed.emit("网络消息发送失败（错误 %d）。" % err)
		return false
	return true

func _broadcast_presence() -> void:
	if not udp_ready:
		return
	var packet := {"kind":"pbl_discovery", "protocol":PROTOCOL_VERSION, "name":local_name, "port":GAME_PORT, "players":local_team.size()}
	udp.set_broadcast_enabled(true)
	udp.set_dest_address("255.255.255.255", DISCOVERY_PORT)
	udp.put_packet(JSON.stringify(packet).to_utf8_buffer())

func _poll_discovery() -> void:
	if not udp_ready:
		return
	while udp.get_available_packet_count() > 0:
		var data := udp.get_packet().get_string_from_utf8()
		var packet = JSON.parse_string(data)
		if not (packet is Dictionary) or str(packet.get("kind", "")) != "pbl_discovery":
			continue
		if int(packet.get("protocol", -1)) != PROTOCOL_VERSION:
			continue
		var ip := udp.get_packet_ip()
		if ip.is_empty() or ip == "127.0.0.1" or IP.get_local_addresses().has(ip):
			continue
		var peer := {"ip":ip, "name":str(packet.get("name", "训练家")), "players":int(packet.get("players", 0))}
		discovered[ip] = peer
		peer_discovered.emit(peer)


func _sanitize_team(raw_team: Array) -> Array:
	var clean_team: Array = []
	for raw_member in raw_team.slice(0, 6):
		if not (raw_member is Dictionary):
			continue
		var member: Dictionary = {
				"name":str(raw_member.get("name", "未命名宝可梦")).left(40),
				"type":str(raw_member.get("type", "一般")).left(12),
				"ability":str(raw_member.get("ability", "")).left(40),
				"item":str(raw_member.get("item", "")).left(40),
				"hp":clampi(int(raw_member.get("hp", 1)), 1, 9999),
				"atk":clampi(int(raw_member.get("atk", 1)), 1, 999),
				"def":clampi(int(raw_member.get("def", 1)), 1, 999),
				"spa":clampi(int(raw_member.get("spa", 1)), 1, 999),
				"spd":clampi(int(raw_member.get("spd", 1)), 1, 999),
				"spe":clampi(int(raw_member.get("spe", 1)), 1, 999),
				"moves":[]
			}
		var raw_moves = raw_member.get("moves", [])
		if raw_moves is Array:
			for move in raw_moves.slice(0, 4):
				member.moves.append(str(move).left(40))
		clean_team.append(member)
	return clean_team

func disconnect_peer() -> void:
	reconnect_enabled = false
	reconnected_this_connection = false
	last_host_ip = ""
	reconnect_attempts = 0
	reconnect_elapsed = 0.0
	stop_discovery()
	if tcp_peer != null:
		tcp_peer.disconnect_from_host()
		tcp_peer = null
	if tcp_server.is_listening():
		tcp_server.stop()
	is_host = false
	connection_state = "offline"
	remote_name = ""
	remote_team.clear()
	rx_buffer = ""
	status_changed.emit("已断开局域网连接。")

func get_connection_state() -> String:
	return connection_state

func _exit_tree() -> void:
	disconnect_peer()
